# Install Yomitan Browser Extension

1. ## Add the Yomitan Extension

    Make sure the display engine is Webview2 (using the browser extension requires Webview2; unless the system does not support Webview2, the default display engine is Webview2), then enable **Use Browser Extension** and add the Yomitan extension.

    >[!WARNING]
    >You should add the Chrome/Edge version of the plugin. The Firefox version of the plugin is not compatible.

    1. ### Method 1: Add the browser extension in Display Settings

        ![img](https://image.lunatranslator.org/en/extension/2.png)

        ![img](https://image.lunatranslator.org/en/extension/1.png)


    1. ### Method 2: Add the browser extension from the right-click menu

        ![img](https://image.lunatranslator.org/en/extension/4.png)

        ![img](https://image.lunatranslator.org/en/extension/5.png)

    ![img](https://image.lunatranslator.org/zh/yomitan2.png)


1. ## Wait for the initialization to complete, then configure Yomitan.

    >[!WARNING]
    >Sometimes after adding a plugin, it may not be recognized. You need to close the software and reopen it for it to be recognized.

    ![img](https://image.lunatranslator.org/en/yomitan4.png)

1. ## Final Result

   > [!TIP]
   > By default, the main window automatically resizes based on the text and translation content, which also adjusts the Yomitan window size.
   >
   > Go to **Display Settings** → **Interface Settings**, and disable **Auto Adjust Height**, or set a **Minimum Height** large enough to accommodate Yomitan.
   >
   > ![img](https://image.lunatranslator.org/en/extension/3.png)

   ![img](https://image.lunatranslator.org/zh/yomitan5.png)

1. In addition to the main interface, the history text window can also use the browser extension, but it is not enabled by default to save resources.

   ![img](https://image.lunatranslator.org/zh/yomitan7.png)

   ![img](https://image.lunatranslator.org/zh/yomitan6.png)

   ![img](https://image.lunatranslator.org/zh/yomitan8.png)