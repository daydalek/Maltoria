# Установка расширения браузера Yomitan

1. ## Добавление расширения Yomitan

    Убедитесь, что движок отображения — Webview2 (для использования расширения браузера необходим Webview2; если система не поддерживает Webview2, по умолчанию движок отображения будет Webview2), затем включите **Использовать расширение браузера** и добавьте расширение Yomitan.

    >[!WARNING]
    >Вам следует добавить плагин для версии Chrome/Edge. Плагин для версии Firefox несовместим.

    1. ### Способ 1: добавление расширения браузера в настройках отображения

        ![img](https://image.lunatranslator.org/en/extension/2.png)

        ![img](https://image.lunatranslator.org/en/extension/1.png)


    1. ### Способ 2: добавление расширения браузера через контекстное меню

        ![img](https://image.lunatranslator.org/en/extension/4.png)

        ![img](https://image.lunatranslator.org/en/extension/5.png)

    ![img](https://image.lunatranslator.org/zh/yomitan2.png)


1. ## Дождитесь завершения инициализации, затем настройте Yomitan.

    >[!WARNING]
    >Иногда после добавления плагина он может не распознаваться. Вам нужно закрыть программное обеспечение и снова открыть его, чтобы он распознался.

    ![img](https://image.lunatranslator.org/en/yomitan4.png)

1. ## Итоговый результат

   > [!TIP]
   > По умолчанию главное окно автоматически изменяет размер в зависимости от текста и содержимого перевода, что также влияет на размер окна Yomitan.
   >
   > Перейдите в **Настройки отображения** → **Настройки интерфейса** и снимите флажок **Автоматическая регулировка высоты** либо задайте **Минимальную высоту**, достаточную для размещения Yomitan.
   >
   > ![img](https://image.lunatranslator.org/en/extension/3.png)

   ![img](https://image.lunatranslator.org/zh/yomitan5.png)

1. Помимо основного интерфейса, расширение браузера можно использовать в окне истории текста, но по умолчанию оно отключено для экономии ресурсов.

   ![img](https://image.lunatranslator.org/zh/yomitan7.png)

   ![img](https://image.lunatranslator.org/zh/yomitan6.png)

   ![img](https://image.lunatranslator.org/zh/yomitan8.png)