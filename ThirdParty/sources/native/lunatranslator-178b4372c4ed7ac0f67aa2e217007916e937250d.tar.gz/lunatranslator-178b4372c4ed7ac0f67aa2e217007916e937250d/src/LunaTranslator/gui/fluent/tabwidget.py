"""FluentTabWidget —— 设置页导航容器（WinUI NavigationView 版）。

左侧主导航（7 项）+ 分隔线 + 底部固定导航（关于软件）+ 右侧 QTabWidget。
兼容 makesubtab_lazy / tabadd_lazy / about.py 动态加页 / setCurrentIndex /
currentChanged / updatelangtext 的全部调用面。
"""

from qtsymbols import (
    QEvent,
    Qt,
    QFrame,
    QHBoxLayout,
    QLabel,
    QModelIndex,
    QParallelAnimationGroup,
    QPixmap,
    QPropertyAnimation,
    QRect,
    QTabBar,
    QTabWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
    pyqtSignal,
    QApplication,
    QColor,
    QEasingCurve,
    QPainter,
    QPainterPath,
    QPen,
    QPalette,
    QPoint,
    QRectF,
    QSizePolicy,
)

import functools
from traceback import print_exc

from myutils.config import _TR
from gui.dynalang import LTabWidget
from gui.fluent.nav import FluentNavTree, FluentNavToggleButton, NAV_PAGE_ROLE, NAV_ICON_ROLE

from gui.fluent.icons import (
    ICON_SETTINGS,
    ICON_CHARACTERS,
    ICON_SETTINGS_DISPLAY_SOUND,
    ICON_PROCESSING,
    ICON_DICTIONARY,
    ICON_AUDIO,
    ICON_KEYBOARD_CLASSIC,
    ICON_INFO,
    ICON_NAV_FALLBACK,
    ICON_GLOBAL_NAV,
)

# 按标题取图标：层级子页加入主 stack 后，位置索引与树序不再一一对应
NAV_ICONS = {
    "核心设置": ICON_SETTINGS,
    "翻译设置": ICON_CHARACTERS,
    "显示设置": ICON_SETTINGS_DISPLAY_SOUND,
    "文本处理": ICON_PROCESSING,
    "辞书设置": ICON_DICTIONARY,
    "语音合成": ICON_AUDIO,
    "快捷按键": ICON_KEYBOARD_CLASSIC,
}

# fluentui3styleproperties.h —— enum TabBarStyle
TABBAR_STYLE_PIVOT_GROW = 3  # Pivot_Grow
TABBAR_STYLE_SEGMENTED_SLIDE = 6  # Segmented_Slide

# 直角面板（FluentSquarePane）配色
PANE_COLORS_PAGE = 0  # 同页卡（FluentPageCard 配方）
PANE_COLORS_CARD = 1  # 同内容卡（插件 isCard 配方）


class FluentCardSeparator(QFrame):
    """侧边栏分割线（游戏管理与设置窗口共用）：颜色与页卡描边一致
    （_pagecard_colors 的描边色，随明暗主题）。
    默认隐藏，followNavScroll 后仅在导航内容溢出（需要滚动）时显示。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(1)
        self.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.hide()

    def paintEvent(self, _):
        painter = QPainter(self)
        painter.fillRect(self.rect(), _pagecard_colors(self)[1])

    def followNavScroll(self, nav):
        """导航内容溢出（需要滚动）时才显示分割线；空间充足时留白。"""
        def sync(*_):
            self.setVisible(nav.verticalScrollBar().maximum() > 0)
        nav.verticalScrollBar().rangeChanged.connect(sync)
        sync()


def _is_dark_theme(w: QWidget):
    """明暗判定：应用级 _q_colorscheme 优先，回退调色板亮度。"""
    app = QApplication.instance()
    if app is not None:
        cs = app.property("_q_colorscheme")
        if cs is not None:
            try:
                return int(cs) == 1
            except Exception:
                pass
    return w.palette().color(QPalette.Window).lightness() < 128


def _pagecard_colors(w: QWidget):
    """页卡配色（FluentPageCard / FluentSquarePane(page) / 分割线共用）：
    浅色 = 调色板 Base(249) + #E9E9E9 描边；暗色 = 窗口色上叠 4% 白
    (≈41) + 白@0x12 描边（插件 pane 的 frameColorLight——偏白，与
    Gallery 暗色页卡一致）。"""
    if _is_dark_theme(w):
        wc = w.palette().color(QPalette.Window)
        fill = QColor(
            round(wc.red() + (255 - wc.red()) * 0.04),
            round(wc.green() + (255 - wc.green()) * 0.04),
            round(wc.blue() + (255 - wc.blue()) * 0.04))
        border = QColor(255, 255, 255, 0x12)
    else:
        fill = QColor(w.palette().color(QPalette.Base))
        border = QColor(0xE9, 0xE9, 0xE9)
    return fill, border


def _contentcard_colors(w: QWidget):
    """内容卡配色（FluentSquarePane(card)，插件 isCard 的 PE_Widget
    配方）：底色 = winUI3CardBackgroundColor（浅色白@179 叠 Base≈253、
    暗色白@13 叠 Base），描边 = cardStrokeColorBalanced（#E9E9E9 /
    #252525，不透明）。"""
    dark = _is_dark_theme(w)
    base = QColor(w.palette().color(QPalette.Base))
    if base.alpha() == 0:
        base = QColor(w.palette().color(QPalette.Window))
    if base.alpha() == 0:
        base = QColor(0x1E, 0x1E, 0x1E) if dark else QColor(0xFF, 0xFF, 0xFF)
    card = QColor(255, 255, 255, 13) if dark else QColor(255, 255, 255, 179)
    alpha = card.alphaF()
    fill = QColor(
        round(base.red() * (1 - alpha) + card.red() * alpha),
        round(base.green() * (1 - alpha) + card.green() * alpha),
        round(base.blue() * (1 - alpha) + card.blue() * alpha))
    border = QColor(0x25, 0x25, 0x25) if dark else QColor(0xE9, 0xE9, 0xE9)
    return fill, border


class FluentPageCard(QWidget):
    """tab 页的圆角包裹卡：底色介于窗口与内容卡之间——
    浅色 = 调色板 Base(249)，暗色 = 窗口色上叠 4% 白(≈41)——
    使「窗口 243/32 → 页面 249/41 → 内容卡 253/50」三级都可分辨。"""

    def paintEvent(self, e):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        fill, border = _pagecard_colors(self)
        path = QPainterPath()
        path.addRoundedRect(
            QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 4, 4)
        painter.fillPath(path, fill)
        painter.setPen(QPen(border, 1.0))
        painter.setBrush(Qt.NoBrush)
        painter.drawPath(path)


class FluentSquarePane(QWidget):
    """直角面板（Gallery 子页签内容的统一包裹，插件 QTabWidget::pane
    直角面板的等价自绘）：四角直角。colorstyle 选配色——'page' 同
    页卡（_pagecard_colors）或 'card' 同内容卡（_contentcard_colors）。"""

    def __init__(self, parent=None, colorstyle=PANE_COLORS_PAGE):
        super().__init__(parent)
        self.colorstyle = colorstyle

    def paintEvent(self, e):
        painter = QPainter(self)
        if self.colorstyle == PANE_COLORS_CARD:
            fill, border = _contentcard_colors(self)
        else:
            fill, border = _pagecard_colors(self)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        painter.fillRect(rect, fill)
        painter.setPen(QPen(border, 1.0))
        painter.setBrush(Qt.NoBrush)
        painter.drawRect(rect)


def apply_pivot_bar_style(bar: QTabBar):
    """裸 QTabBar 的 Pivot_Grow 配置（segmented 全面退场的替代）：
    无样式化底（插件对带底 QTabBar 画分段容器底）、drawBase 默认值经
    插件 PE_FrameTabBarBase 空实现不画、紧凑排布（不均分宽度；
    需均分的调用方随后自行 setExpanding(True)）。"""
    bar.setProperty("tabBarStyle", TABBAR_STYLE_PIVOT_GROW)
    bar.setAttribute(Qt.WA_StyledBackground, False)
    bar.setDrawBase(True)
    bar.setExpanding(False)


def apply_segmented_slide_bar_style(bar: QTabBar):
    """裸 QTabBar 的 Segmented_Slide 配置：分段容器底（带
    WA_StyledBackground 时插件画容器）+ 选中段实心拇指滑动过渡。"""
    bar.setProperty("tabBarStyle", TABBAR_STYLE_SEGMENTED_SLIDE)
    bar.setAttribute(Qt.WA_StyledBackground, True)
    bar.setDrawBase(False)
    bar.setExpanding(False)


class FluentPaneTabWidget(LTabWidget):
    """Gallery 式页签组（pageaudiolevelmeter.cpp 基础/刻度/动画/颜色
    tab 同款）：tabbar 样式可参数化（tabbar_style，默认 Pivot_Grow——
    无底文字页签 + 选中底部 24px 强调色圆头短横线，切换时指示条自
    旧位置拉伸过渡至新位置），各页统一包在直角面板里（四角直角，
    面板顶边紧贴 tabbar）。colorstyle 选面板配色——PANE_COLORS_PAGE
    （同页卡，默认）或 PANE_COLORS_CARD（同内容卡 isCard）。
    addTab 自动包裹页 widget（懒加载页的 lazyfunction 属性随页迁移）。
    宿主一般再包一张内容卡（make_content_card）。"""

    def __init__(self, parent=None, tabbar_style=TABBAR_STYLE_PIVOT_GROW,
                 colorstyle=PANE_COLORS_PAGE):
        super().__init__(parent)
        self._colorstyle = colorstyle
        bar = self.tabBar()
        bar.setProperty("tabBarStyle", tabbar_style)
        # 无底文字页签：bar 无样式化底（drawBase 默认值经插件
        # PE_FrameTabBarBase 空实现不画任何东西）
        bar.setAttribute(Qt.WA_StyledBackground, False)
        bar.setDrawBase(True)
        # pane 清零：面板由页自带，插件 pane 内边距不叠加
        self.setStyleSheet(
            "QTabWidget::pane{border:0;margin:0;padding:0;}")

    def addTab(self, w, t):
        if self._colorstyle == 3:
            return LTabWidget.addTab(self, w, t)
        q = QWidget()
        v = QVBoxLayout(q)
        v.setContentsMargins(0, 0, 0, 0)
        pane = FluentSquarePane(colorstyle=self._colorstyle)
        v.addWidget(pane)
        inner = QVBoxLayout(pane)
        inner.setContentsMargins(0, 0, 0, 0)
        inner.addWidget(w)
        if hasattr(w, "lazyfunction"):
            q.lazyfunction = w.lazyfunction
        return LTabWidget.addTab(self, q, t)


def make_content_card(w, margins=(16, 8, 16, 16)):
    """内容卡（isCard）包裹——Gallery propertiesCard 同款；
    margins 默认 (16, 8, 16, 16)：内容距卡左右 16、顶 8（bar 下移）、底 16。"""
    card = QWidget()
    card.setAttribute(Qt.WA_StyledBackground, True)
    card.setProperty("isCard", True)
    lay = QVBoxLayout(card)
    lay.setContentsMargins(*margins)
    lay.addWidget(w)
    return card


class _NoPaneTabWidget(QTabWidget):
    """QTabWidget::paintEvent 只画 pane（PE_FrameTabWidget：1px 边框 +
    Base 底色）。置空以去掉 pane——不能用 QSS，容器级样式表会给全部
    后代套 QStyleSheetStyle，破坏插件渲染与字体继承。

    切页滑动动画（Gallery ExTabWidget / 主窗口 ExStackedWidget 同款：
    纵向、300ms、InOutSine）：currentChanged 后把前后两页 render 成
    QPixmap，用两个透明 QLabel 覆盖层做平移动画，结束后回到真实页面。
    animatePageChange 必须连在 FluentTabWidget.__stack_changed 之后——
    懒加载页在同一次 currentChanged 里构建，渲染要等构建完成。"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._duration = 300
        self._curve = QEasingCurve.Type.InOutSine
        self._animating = False
        self._last_index = -1
        self._current_overlay = None
        self._next_overlay = None
        self._animation_group = None

    def paintEvent(self, e):
        pass

    def setCurrentIndex(self, index):
        # 先把懒加载页构建完再切页：动画滑入的即是完整内容（也保证
        # 页面先走正常显示流程，覆盖层 render 到的快照不是未上妆的
        # 空壳）。构建后 makesubtab_lazy 的 __ 里 lazyfunction 已删，
        # 不会重复构建。
        w = self.widget(index) if 0 <= index < self.count() else None
        lf = getattr(w, "lazyfunction", None)
        if lf is not None:
            delattr(w, "lazyfunction")
            try:
                lf()
            except:
                print_exc()
        super().setCurrentIndex(index)

    def animatePageChange(self, index):
        if index < 0 or index >= self.count():
            return
        if self._animating:
            self._finish_animation()
        if (
            not self.isVisible()
            or self._last_index < 0
            or self._last_index == index
            or self._duration <= 0
        ):
            self._last_index = index
            return
        current_widget = self.widget(self._last_index)
        next_widget = self.widget(index)
        if not current_widget or not next_widget:
            self._last_index = index
            return
        stack = current_widget.parentWidget() or self
        area = QRect(QPoint(0, 0), stack.size())
        if area.isEmpty():
            self._last_index = index
            return
        # 懒加载页刚构建完，布局是脏的（LayoutRequest 还在队列里）——
        # 强制激活，否则 render 出的快照里子控件位置不对
        for page in (current_widget, next_widget):
            page.resize(area.size())
            if page.layout() is not None:
                page.layout().activate()
        current_pixmap = QPixmap(area.size())
        current_pixmap.fill(Qt.GlobalColor.transparent)
        current_widget.render(current_pixmap)
        next_pixmap = QPixmap(area.size())
        next_pixmap.fill(Qt.GlobalColor.transparent)
        next_widget.render(next_pixmap)

        current_overlay = QLabel(stack)
        current_overlay.setPixmap(current_pixmap)
        current_overlay.setScaledContents(False)
        current_overlay.setGeometry(area)
        current_overlay.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        current_overlay.show()
        current_overlay.raise_()

        next_overlay = QLabel(stack)
        next_overlay.setPixmap(next_pixmap)
        next_overlay.setScaledContents(False)
        next_overlay.setAttribute(Qt.WA_TransparentForMouseEvents, True)

        # 纵向滑动：前进（索引增大）= 旧页上移出、新页自下方进入
        forward = index > self._last_index
        offset = area.height()
        current_end = QPoint(0, -offset if forward else offset)
        next_start = QPoint(0, offset if forward else -offset)

        next_overlay.setGeometry(QRect(next_start, area.size()))
        next_overlay.show()
        next_overlay.raise_()

        # 动画期间真实页面藏起，只见覆盖层
        next_widget.hide()

        current_animation = QPropertyAnimation(current_overlay, b"pos", self)
        current_animation.setDuration(self._duration)
        current_animation.setEasingCurve(self._curve)
        current_animation.setStartValue(QPoint(0, 0))
        current_animation.setEndValue(current_end)

        next_animation = QPropertyAnimation(next_overlay, b"pos", self)
        next_animation.setDuration(self._duration)
        next_animation.setEasingCurve(self._curve)
        next_animation.setStartValue(next_start)
        next_animation.setEndValue(QPoint(0, 0))

        group = QParallelAnimationGroup(self)
        group.addAnimation(current_animation)
        group.addAnimation(next_animation)

        self._animating = True
        self._current_overlay = current_overlay
        self._next_overlay = next_overlay
        self._animation_group = group
        self._last_index = index
        group.finished.connect(self._finish_animation)
        group.start()

    def _finish_animation(self):
        if self._animation_group is not None:
            self._animation_group.stop()
            self._animation_group.deleteLater()
            self._animation_group = None
        current = self.currentWidget()
        if current is not None:
            current.show()
        for attr in ("_current_overlay", "_next_overlay"):
            overlay = getattr(self, attr)
            if overlay is not None:
                overlay.deleteLater()
                setattr(self, attr, None)
        self._animating = False


def make_lazy_page(getrealwidgetfunction, main=True):
    """懒加载页占位：FluentPageCard 圆角卡包裹 + lazyfunction（构建由
    首次选中触发）。main=True 主 stack 页（_fluent_main_grid），否则为
    子页签卡内网格（_fluent_card_grid）。"""
    q = QWidget()
    v = QVBoxLayout(q)
    v.setContentsMargins(0, 0, 0, 0)
    card = FluentPageCard()
    v.addWidget(card)
    innerlay = QVBoxLayout(card)
    innerlay.setContentsMargins(0, 0, 0, 0)
    innerlay.setProperty("_fluent_main_grid" if main else "_fluent_card_grid", True)
    q.lazyfunction = functools.partial(getrealwidgetfunction, innerlay)
    return q



class FluentTabWidget(QWidget):
    currentChanged = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.__titles = []
        self.__child_pages = []  # (QTreeWidgetItem, 原始标题)——层级子节点
        self.__syncing = False

        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # ---- 导航栏结构照抄 Gallery ExWinUINavigationView ----
        nav_pane = QWidget(self)
        nav_lay = QVBoxLayout(nav_pane)
        nav_lay.setContentsMargins(0, 0, 0, 0)
        nav_lay.setSpacing(0)

        # 主导航（可伸展）；容器边距 (6,6,6,0)——下边贴分隔线
        main_container = QWidget(nav_pane)
        main_lay = QVBoxLayout(main_container)
        main_lay.setContentsMargins(6, 6, 6, 0)
        main_lay.setSpacing(0)
        # 汉堡：导航窗格第一行（同游戏管理器共用组件；标题栏不放导航按钮）
        self.nav_toggle_button = FluentNavToggleButton(main_container)
        self.nav_toggle_button.setText(ICON_GLOBAL_NAV)
        self.nav_toggle_button.setToolTip("折叠/展开侧边栏")
        self.nav_toggle_button.clicked.connect(self.toggleNavigation)
        main_lay.addWidget(self.nav_toggle_button)
        self.nav = FluentNavTree(main_container)
        main_lay.addWidget(self.nav)

        # 分隔线：整宽、页卡描边色；仅导航溢出（可滚动）时显示
        self._nav_separator = FluentCardSeparator(nav_pane)
        self._nav_separator.followNavScroll(self.nav)

        # 底部固定导航（关于软件，不参与伸展）；容器边距 (6,0,6,6)——上边贴分隔线
        footer_container = QWidget(nav_pane)
        footer_lay = QVBoxLayout(footer_container)
        footer_lay.setContentsMargins(6, 0, 6, 6)
        footer_lay.setSpacing(0)
        self.nav_footer = FluentNavTree(footer_container, footer=True)
        self.nav_footer.setFixedHeight(38)
        footer_lay.addWidget(self.nav_footer)

        nav_lay.addWidget(main_container, 1)
        nav_lay.addWidget(self._nav_separator, 0)
        nav_lay.addWidget(footer_container, 0)

        self.tab_widget = _NoPaneTabWidget(self)
        self.tab_widget.tabBar().hide()
        # 插件给 QTabWidget pane 自带内边距（页卡四边被缩进 2-4px，
        # 右侧离窗口框架不贴）——置空 pane 边距，页卡与窗口边缘重合
        self.tab_widget.setStyleSheet(
            "QTabWidget::pane{border:0;margin:0;padding:0;}")

        lay.addWidget(nav_pane)
        lay.addWidget(self.tab_widget, 1)

        # 单一发射点：stack 变化 -> currentChanged（makesubtab_lazy 据此懒加载）
        self.nav.pageIndexChanged.connect(self.__nav_changed)
        self.nav_footer.pageIndexChanged.connect(self.__nav_changed)
        # 切页滑动动画：连在 __stack_changed 之后——懒加载页在同一次
        # currentChanged 里构建，动画覆盖层的渲染须等构建完成
        self.tab_widget.currentChanged.connect(self.__stack_changed)
        self.tab_widget.currentChanged.connect(self.tab_widget.animatePageChange)
        # 主导航展开/收起 -> 底部导航跟随（两棵树独立）
        self.nav.navigationExpandedChanged.connect(
            self.nav_footer.setNavigationExpanded)

        # 跨导航取消选中（点主导航时清底部，反之亦然）
        self.nav.currentItemChanged.connect(
            lambda cur, _prev: self.__cross_select(self.nav_footer))
        self.nav_footer.currentItemChanged.connect(
            lambda cur, _prev: self.__cross_select(self.nav))

        # 默认展开（同 Win11 设置）
        self.nav.setNavigationExpanded(True, animated=False)
        self.nav_footer.setNavigationExpanded(True, animated=False)

    # ---- 跨导航取消选中 ----
    def __cross_select(self, peer):
        if peer.selectionModel() and peer.selectionModel().hasSelection():
            peer.blockSignals(True)
            peer.clearSelection()
            peer.setCurrentIndex(QModelIndex())
            peer.blockSignals(False)
            if peer.viewport():
                peer.viewport().update()

    # ---- TabWidget 兼容面 ----
    def addTab(self, widget, title):
        self.__titles.append(title)
        self.tab_widget.addTab(widget, _TR(title))
        idx = self.tab_widget.count() - 1
        if "关于" in title:
            # 底部固定导航，不自动选中
            self.nav_footer.addNavigationItem(
                _TR(title), idx, ICON_INFO, auto_select=False)
        else:
            icon = NAV_ICONS.get(title, ICON_NAV_FALLBACK)
            self.nav.addNavigationItem(_TR(title), idx, icon)

    # ---- 层级子导航（同 Gallery mainwindow 的 add_nav_child） ----
    def navPageIndex(self, title):
        """顶层页标题 -> stack 索引（__titles 与 stack 顺序一致）。"""
        try:
            return self.__titles.index(title)
        except ValueError:
            return None

    def addNavChildPage(self, parent_title, title, getrealwidgetfunction=None,
                        page_index=None):
        """把页面挂为 parent_title 导航项的子节点（WinUI 层级导航）。
        page_index 给定时复用已有页面（父项与首子项同页），否则新建
        懒加载页加入主 stack。返回页索引。"""
        if page_index is None:
            q = make_lazy_page(getrealwidgetfunction)
            self.tab_widget.addTab(q, _TR(title))
            page_index = self.tab_widget.count() - 1
        parent_page = self.navPageIndex(parent_title)
        parent = self._find_item_by_page(parent_page) if parent_page is not None else None
        if parent is not None:
            child = QTreeWidgetItem(parent)
            self.nav.configureNavigationItem(child, _TR(title), page_index, "")
            self.__child_pages.append((child, title))
            # 父项默认折叠（单击父项整行展开/折叠，见 FluentNavTree）
        return page_index

    def _find_item_by_page(self, page_index):
        """在主导航/底部导航中递归查找指向 page_index 的节点（含子节点）。"""
        if page_index is None:
            return None
        for tree in (self.nav, self.nav_footer):
            item = self._find_item_by_page_r(tree.invisibleRootItem(), page_index)
            if item is not None:
                return item
        return None

    @staticmethod
    def _find_item_by_page_r(root, page_index):
        for i in range(root.childCount()):
            item = root.child(i)
            if item.data(0, NAV_PAGE_ROLE) == page_index:
                return item
            found = FluentTabWidget._find_item_by_page_r(item, page_index)
            if found is not None:
                return found
        return None

    def setCurrentIndex(self, idx):
        if idx < 0 or idx >= self.tab_widget.count():
            return
        item = self._find_item_by_page(idx)
        if item is not None:
            # 子节点需展开祖先链才可见
            p = item.parent()
            while p is not None:
                p.setExpanded(True)
                p = p.parent()
            tree = item.treeWidget()
            if tree.currentItem() is not item:
                tree.setCurrentItem(item)
            return
        # 兜底：直接切 stack
        if self.tab_widget.currentIndex() != idx:
            self.tab_widget.setCurrentIndex(idx)

    def currentIndex(self):
        return self.tab_widget.currentIndex()

    def currentWidget(self):
        return self.tab_widget.currentWidget()

    def widget(self, idx):
        return self.tab_widget.widget(idx)

    def count(self):
        return self.tab_widget.count()

    def adjust_list_widget_width(self):
        pass  # 导航宽度固定（44/200），无需按字体测量

    def toggleNavigation(self):
        # 底部导航由 navigationExpandedChanged 信号跟随——这里再显式
        # toggle 会把它翻回去（信号先设一次，相对翻转会抵消）
        self.nav.toggleNavigationMode()

    def setNavigationExpanded(self, expanded, animated=True):
        """展开/收起侧边栏（主导航；底部导航经信号跟随）。"""
        self.nav.setNavigationExpanded(expanded, animated)

    def navigationExpanded(self):
        return self.nav.navigationExpanded()

    # ---- 语言切换 ----
    def updatelangtext(self):
        for i, title in enumerate(self.__titles):
            self.tab_widget.setTabText(i, _TR(title))
        for i in range(self.nav.topLevelItemCount()):
            item = self.nav.topLevelItem(i)
            if item is not None:
                self.nav.configureNavigationItem(
                    item, _TR(self.__titles[item.data(0, NAV_PAGE_ROLE)]),
                    item.data(0, NAV_PAGE_ROLE), item.data(0, NAV_ICON_ROLE))
        for i in range(self.nav_footer.topLevelItemCount()):
            item = self.nav_footer.topLevelItem(i)
            if item is not None:
                self.nav_footer.configureNavigationItem(
                    item, _TR(self.__titles[item.data(0, NAV_PAGE_ROLE)]),
                    item.data(0, NAV_PAGE_ROLE), item.data(0, NAV_ICON_ROLE))
        for item, title in self.__child_pages:
            if item is not None:
                self.nav.configureNavigationItem(
                    item, _TR(title), item.data(0, NAV_PAGE_ROLE), "")

    def changeEvent(self, event):
        if event is not None and event.type() == QEvent.Type.LanguageChange:
            self.updatelangtext()
        return super().changeEvent(event)

    # ---- 内部 ----
    def __nav_changed(self, idx):
        if self.__syncing:
            return
        self.__syncing = True
        try:
            if self.tab_widget.currentIndex() != idx:
                self.tab_widget.setCurrentIndex(idx)
        finally:
            self.__syncing = False

    def __stack_changed(self, idx):
        self.currentChanged.emit(idx)
