"""OCR translation display, source provenance, and capture exclusion.

No changes to translation engines or user credentials are required.
"""

import ctypes
import math
import threading
import weakref
from contextlib import contextmanager

from qtsymbols import *
import windows, NativeUtils
from myutils.config import globalconfig


class OCRCaptureSnapshot():
    """Selection revision and physical rectangle at the start of recognition."""

    def __init__(self,revision : int, rect: tuple):
        self.revision = revision
        self.rect = rect

    def __eq__(self, other):
        if not isinstance(other, OCRCaptureSnapshot):
            return NotImplemented
        return self.revision == other.revision and self.rect == other.rect

class OCRRegionText(str):
    """Plain text at existing API/storage boundaries, with transient provenance.

    OCR managers attach this source to the parsed result at recognition commit.
    Dispatch must reuse it, rather than relabeling the result with a later revision.
    block_index 携带块级来源（原地按位置绘制）：None = 整个选框一条译文。
    """

    def __new__(cls, text, target, revision, owner=None, block_index=None):
        obj = super().__new__(cls, text)
        obj.ocr_overlay_context = (weakref.ref(target), revision)
        obj.ocr_overlay_owner = weakref.ref(owner) if owner is not None else None
        obj.ocr_block_index = block_index
        return obj


class OCRRegionBatch(str):
    def __new__(cls, sources):
        sources = tuple(sources)
        obj = super().__new__(cls, "\n".join(sources))
        obj.ocr_region_sources = sources
        return obj


def overlay_source_is_current(source):
    context = getattr(source, "ocr_overlay_context", None)
    if context is None:
        return False
    target, revision = context
    target = target()
    if target is None or target._ocr_overlay_revision != revision:
        return False
    owner_ref = getattr(source, "ocr_overlay_owner", None)
    if owner_ref is not None:
        owner = owner_ref()
        if owner is None or getattr(owner, "ending", False):
            return False
        if not any(r.range_ui is target for r in owner.ranges):
            return False
    return True


class OCRRegionTask:
    # The translator queue treats this as a protected request. Its validity is
    # per region, so a newer request from another region cannot cancel it.
    # 不再看 ocr_translation_overlay 全局开关：单次OCR常驻容器等场景没有
    # 开关也要保证任务有效（是否上屏由显示侧各自决定）。
    ocr_overlay_task = True

    def __init__(self, source):
        self.source = source

    def is_current(self):
        return overlay_source_is_current(self.source)


def overlay_source_displays(source):
    """该来源的译文是否应走覆盖层：全局 原地显示翻译 开关开启，或来源
    所在容器强制原地显示（单次OCR常驻容器）。"""
    if not overlay_source_is_current(source):
        return False
    if globalconfig.get("ocr_translation_overlay", False):
        return True
    target, _ = source.ocr_overlay_context
    target = target()
    overlay = getattr(target, "translation_overlay", None)
    return overlay is not None and overlay.display_always


def route_overlay_translation(source, engine, text):
    if not overlay_source_is_current(source):
        return
    target, revision = source.ocr_overlay_context
    target = target()
    try:
        target.overlaytranslationsignal.emit(
            (revision, engine, text, getattr(source, "ocr_block_index", None))
        )
    except RuntimeError:
        # The region may have been closed while an engine was finishing.
        pass


_overlays = weakref.WeakSet()
_capture_guard = None
_capture_suspensions = 0

# 原地显示翻译的对齐方式（设置页 combobox 的 internal 值 -> Qt 旗标）。
# 用 int 组合：TextFlag | (Alignment 旗标对象) 在 PyQt5 下会 TypeError，
# 且 paintEvent 内的异常会直接 qFatal 整个进程。
_OVERLAY_ALIGN_FLAGS = {
    "topleft": int(Qt.AlignmentFlag.AlignLeft) | int(Qt.AlignmentFlag.AlignTop),
    "topright": int(Qt.AlignmentFlag.AlignRight) | int(Qt.AlignmentFlag.AlignTop),
    "topcenter": int(Qt.AlignmentFlag.AlignHCenter) | int(Qt.AlignmentFlag.AlignTop),
    "center": int(Qt.AlignmentFlag.AlignHCenter) | int(Qt.AlignmentFlag.AlignVCenter),
}
_OVERLAY_ALIGN_DEFAULT = "topleft"
# 适配/扩展共用的测量旗标（左对齐换行测量所需宽高）
_OVERLAY_MEASURE_FLAGS = int(Qt.TextFlag.TextWordWrap) | int(
    Qt.AlignmentFlag.AlignLeft
)


def ocr_popup_is_visible():
    # Readable from the main window's topmost check without querying widgets.
    # （选区菜单都包在 suspend_ocr_capture 里，计入 _capture_suspensions）
    return bool(_capture_suspensions)


@contextmanager
def suspend_ocr_capture():
    """Keep OCR from capturing selection menus, including in-flight captures."""
    global _capture_suspensions
    _capture_suspensions += 1
    try:
        yield
    finally:
        # The popup has closed; wait for its pixels to leave the composed frame.
        try:
            ctypes.windll.dwmapi.DwmFlush()
        except (AttributeError, OSError):
            pass
        _capture_suspensions -= 1


class _CaptureRequest:
    def __init__(self, rect, probe, desktop):
        self.rect = rect
        self.probe = probe      # ③ 探测（未命中返回空 QImage）
        self.desktop = desktop  # ④ 桌面截图
        self.finished = threading.Event()
        self.result = QImage()
        self.error = None
        self.cancelled = False


class _CaptureGuard(QObject):
    requested = pyqtSignal(object)

    def __init__(self):
        super().__init__(QApplication.instance())
        self.requested.connect(self.run)

    def run(self, request):
        hidden = []
        excluded = []
        try:
            if request.cancelled or _capture_suspensions:
                return
            rect = request.rect
            # ② 覆盖层默认不排除（录屏要能录到译文）：截图瞬间临时排除
            # （Win10 2004+），截完恢复。只处理与本次截图矩形相交的覆盖
            # 层——多区域时别区域的覆盖层不在画面里，不参与（不闪）
            for overlay in list(_overlays):
                if (
                    not overlay.capture_excluded
                    and overlay.isVisible()
                    and _overlay_intersects(overlay, rect)
                ):
                    if NativeUtils.ExcludeFromCapture(int(overlay.winId())):
                        overlay.capture_excluded = True
                        excluded.append(overlay)
            # ③ 唯一不透明窗口（成功即用——窗口自身 DC 不含覆盖层，
            # 不落桌面、无须隐藏）
            request.result = request.probe()
            if not request.result.isNull():
                return
            # ④ 排除不掉的（旧系统）才隐藏，然后落桌面
            for overlay in list(_overlays):
                if (
                    not overlay.capture_excluded
                    and overlay.isVisible()
                    and _overlay_intersects(overlay, rect)
                ):
                    overlay.hide()
                    hidden.append(overlay)
            if hidden or excluded:
                # Wait for composition before capturing; no QWidget access in workers.
                try:
                    ctypes.windll.dwmapi.DwmFlush()
                except (AttributeError, OSError):
                    pass
            request.result = request.desktop()
        except Exception as error:
            request.error = error
        finally:
            for overlay in excluded:
                # 恢复默认（可录屏）状态
                NativeUtils.ClearFromCapture(int(overlay.winId()))
                overlay.capture_excluded = False
            for overlay in hidden:
                overlay.sync()
            request.finished.set()


def _overlay_intersects(overlay, rect):
    """覆盖层窗口是否与截图矩形相交（都是物理屏幕坐标；覆盖层恰好
    盖住自己的选区，_last_rect 由 sync 缓存，工作线程可读）。
    rect 未知（None）或覆盖层位置未知时保守视为相交。"""
    if rect is None:
        return True
    last = overlay._last_rect
    if not last:
        return True
    x, y, w, h, _dpr = last
    return (
        max(x, rect.x()) < min(x + w, rect.x() + rect.width())
        and max(y, rect.y()) < min(y + h, rect.y() + rect.height())
    )


def capture_without_overlays(rect, probe, desktop):
    """守卫作用域内截图（次序见 imageCutEx）：② 临时排除相交覆盖层 →
    ③ probe → ④ 隐藏未排除掉的覆盖层后 desktop。失败/菜单等显式挂起
    （suspend_ocr_capture）期间返回空 QImage。无相交覆盖层时无须
    排除/隐藏，也不必线程编组（工作线程直接跑）。"""
    guard = _capture_guard
    if _capture_suspensions:
        return QImage()

    def _probe():
        # ③ 同 ①：目标窗口自身 DC 与我们的窗口无关，不受遮挡拦截
        if probe is None or _capture_suspensions:
            return QImage()
        return probe()

    def _desktop():
        # 菜单等显式挂起（suspend_ocr_capture）期间不截桌面，挂起期间
        # 截到的画面作废
        if _capture_suspensions:
            return QImage()
        img = desktop()
        return img if not _capture_suspensions else QImage()

    # 无相交覆盖层：无须排除/隐藏，也不必线程编组（工作线程直接跑）
    if guard is None or not any(
        o._capture_visible
        and not o.capture_excluded
        and _overlay_intersects(o, rect)
        for o in list(_overlays)
    ):
        img = _probe()
        if img.isNull():
            img = _desktop()
        return img
    request = _CaptureRequest(rect, _probe, _desktop)
    if QThread.currentThread() == guard.thread():
        guard.run(request)
    else:
        guard.requested.emit(request)
        if not request.finished.wait(2):
            request.cancelled = True
    if request.error is not None:
        raise request.error
    return request.result


def refresh_overlays():
    """显示设置变化（译文跟随字号/字体/居中显示等）后重算覆盖层。

    sync 幂等：paint_key 变化才触发重绘。"""
    for overlay in list(_overlays):
        try:
            overlay.sync()
        except RuntimeError:
            pass


class OCRTranslationOverlay(QWidget):
    def __init__(self, region):
        super().__init__(region)
        self._native_ready = False
        self._capture_visible = False
        self._applying_native_flags = False
        self._native_hwnd = None
        self._geometry_window_handle = None
        self._last_rect = None
        self._last_paint_key = None
        self.region = region
        self.results = {}
        self.text = ""
        self.revision = region._ocr_overlay_revision
        # 块级显示（原地按位置绘制）：块区域（选框图像物理像素）与
        # 每块各引擎的译文。无块区域（图片翻译/不输出坐标的 OCR）时
        # 走整框绘制（self.text）。
        self.block_rects = None
        self.block_results = {}
        # 单次OCR常驻容器等：不受全局 原地显示翻译 开关控制，强制上屏
        self.display_always = False
        self.setWindowFlags(
            Qt.WindowType.Tool
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.WindowTransparentForInput
            | Qt.WindowType.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.capture_excluded = False
        _overlays.add(self)
        global _capture_guard
        if _capture_guard is None:
            _capture_guard = _CaptureGuard()
        self._native_ready = True

    def _apply_native_flags(self):
        if not self._native_ready or self._applying_native_flags:
            return
        self._applying_native_flags = True
        try:
            hwnd = int(self.winId())
            if hwnd != self._native_hwnd:
                self._last_rect = None
                self._native_hwnd = hwnd
            handle = self.windowHandle()
            if handle is not None and handle is not self._geometry_window_handle:
                handle.screenChanged.connect(self._resync_screen_geometry)
                self._geometry_window_handle = handle
            windows.WindowFocus.giveup(hwnd)
            windows.MouseTrans.set(hwnd)
            # 默认不设置截图排除（录屏要能录到译文）；OCR 落桌面截图时
            # 由 CaptureGuard 截图瞬间临时排除、失败才隐藏
            self.capture_excluded = False
        finally:
            self._applying_native_flags = False

    def event(self, event):
        result = super().event(event)
        if (
            event.type() == QEvent.Type.WinIdChange
            and getattr(self, "_native_ready", False)
            and self.isVisible()
        ):
            self._apply_native_flags()
        return result

    def _resync_screen_geometry(self, *_):
        # Qt applies a suggested size when native movement crosses monitors
        # with different DPI. Restore the selection's physical rectangle
        # after that transition, even when no new OCR result arrives.
        self._last_rect = None
        QTimer.singleShot(0, self.sync)

    def showEvent(self, event):
        super().showEvent(event)
        self._capture_visible = True
        # Qt may replace the native handle or reset its flags on first show.
        self._last_rect = None
        self._apply_native_flags()

    def hideEvent(self, event):
        self._capture_visible = False
        super().hideEvent(event)

    @staticmethod
    def _preferred_text(results: dict):
        # 同主窗口的引擎优先级：首选引擎 > 排序列表 > 任意
        preferred = globalconfig.get("toppest_translator")
        if preferred in results:
            return results[preferred]
        for key in globalconfig.get("fix_translate_rank_rank", []):
            if key in results:
                return results[key]
        return next(iter(results.values()), "")

    def _blocktexts(self):
        """当前可绘制的块译文：[(块序号, 译文), ...]。"""
        if not self.block_rects:
            return []
        out = []
        for i in range(len(self.block_rects)):
            texts = self.block_results.get(i)
            if not texts:
                continue
            text = self._preferred_text(texts)
            if text:
                out.append((i, text))
        return out

    def _accept_revision(self, revision, clear=False):
        """载荷的 revision 与当前选区一致才接受；revision 推进（或
        clear）时清空旧译文。"""
        if revision != self.region._ocr_overlay_revision:
            return False
        if revision != self.revision or clear:
            self.results.clear()
            self.text = ""
            self.block_results.clear()
            self.revision = revision
        return True

    def receive(self, payload):
        revision, engine, text, blockidx = payload
        if not self._accept_revision(revision, engine is None):
            return
        if engine is not None and text:
            if blockidx is None:
                self.results[engine] = text
                self.text = self._preferred_text(self.results)
            else:
                self.block_results.setdefault(blockidx, {})[engine] = text
        self.sync()

    def receive_layout(self, payload):
        """识别提交时发布的块区域布局（信号从 OCR 工作线程排队而来）。

        rects：各块 box4（选框图像物理像素）；None = 本轮无坐标，退回
        整框绘制。布局先于块译文到达。"""
        revision, rects = payload
        if not self._accept_revision(revision):
            return
        self.block_rects = tuple(tuple(r) for r in rects) if rects else None
        self.sync()

    def background_color(self):
        color = QColor(
            globalconfig.get("ocr_translation_overlay_background", "#ffffffff")
        )
        if not color.isValid():
            color = QColor(Qt.GlobalColor.white)
        return color

    def text_color(self):
        color = QColor(globalconfig.get("ocr_translation_overlay_textcolor", "#000000"))
        if not color.isValid():
            color = QColor(Qt.GlobalColor.black)
        return color

    def sync(self):
        rect = self.region.getrect()
        if (
            not (
                globalconfig.get("ocr_translation_overlay", False)
                or self.display_always
            )
            or not (self.text or self._blocktexts())
            or not rect.isValid()
            or not self.region.isVisible()
        ):
            if self.isVisible():
                self.hide()
            return
        showing = not self.isVisible()
        if showing:
            self.show()
        geometry = (
            rect.x(),
            rect.y(),
            rect.width(),
            rect.height(),
            self.devicePixelRatioF(),
        )
        if geometry != self._last_rect:
            # Avoid MoveWindow(repaint=True) on every 10 ms follow-window tick.
            windows.MoveWindow(int(self.winId()), *geometry[:4], False)
            self._last_rect = geometry
        if showing:
            self.raise_()
            # A pending translation can show another overlay while a selection
            # menu's nested event loop is running. Keep its popup on top.
            popup = QApplication.activePopupWidget()
            if popup is not None:
                popup.raise_()
        paint_key = (
            self.text,
            self.block_rects,
            tuple(
                sorted(
                    (k, tuple(sorted(v.items())))
                    for k, v in self.block_results.items()
                )
            ),
            geometry,
            globalconfig.get("fonttype2", ""),
            globalconfig.get("fontsize", 16),
            globalconfig.get("showbold_trans", False),
            globalconfig.get("showitalic_trans", False),
            globalconfig.get(
                "ocr_translation_overlay_alignment", _OVERLAY_ALIGN_DEFAULT
            ),
            globalconfig.get("ocr_translation_overlay_background", "#ffffffff"),
            globalconfig.get("ocr_translation_overlay_textcolor", "#000000"),
        )
        if showing or paint_key != self._last_paint_key:
            self._last_paint_key = paint_key
            self.update()

    def _translation_font(self):
        """译文字体（字体/字号/加粗/倾斜设置，同主窗口译文显示）。"""
        font = QFont(globalconfig.get("fonttype2", "") or "Microsoft YaHei")
        try:
            size = float(globalconfig.get("fontsize", 16))
        except (TypeError, ValueError):
            size = 16
        if size > 0:
            font.setPointSizeF(size)
        font.setBold(globalconfig.get("showbold_trans", False))
        font.setItalic(globalconfig.get("showitalic_trans", False))
        return font

    def fitted_font(self, text_rect, text=None, maximum=100):
        """按区域尺寸二分适配字号；下限 12——分析出的字号不能过小，
        放不下时由调用方扩展绘制区域（见 _expanded_text_rect）。"""
        if text is None:
            text = self.text
        font = self._translation_font()
        # Fit by pixel size so the requested size has the same meaning across Qt versions.
        low, high = min(12, maximum), maximum
        while low < high:
            size = (low + high + 1) // 2
            font.setPixelSize(size)
            bounds = QFontMetrics(font).boundingRect(
                text_rect, _OVERLAY_MEASURE_FLAGS, text
            )
            if (
                bounds.height() <= text_rect.height()
                and bounds.width() <= text_rect.width()
            ):
                low = size
            else:
                high = size - 1
        font.setPixelSize(low)
        return font

    @staticmethod
    def _text_fits(font, text_rect, text):
        bounds = QFontMetrics(font).boundingRect(
            text_rect, _OVERLAY_MEASURE_FLAGS, text
        )
        return (
            bounds.width() <= text_rect.width()
            and bounds.height() <= text_rect.height()
        )

    def _expanded_text_rect(self, inner, font, text, bounds=None):
        """块内放不下时的扩展绘制区：按块宽换行所需的尺寸放大、按对齐
        锚点定位、再平移回绘制范围内——译文必须完整显示，不能被裁掉。
        bounds：当前坐标系的可用范围（水平块=选框，倾斜块=局部范围）。"""
        fm = QFontMetrics(font)
        needed = fm.boundingRect(
            QRect(0, 0, inner.width(), 1 << 20), _OVERLAY_MEASURE_FLAGS, text
        )
        w = max(inner.width(), needed.width())
        needed = fm.boundingRect(
            QRect(0, 0, w, 1 << 20), _OVERLAY_MEASURE_FLAGS, text
        )
        h = max(inner.height(), needed.height())
        align = globalconfig.get(
            "ocr_translation_overlay_alignment", _OVERLAY_ALIGN_DEFAULT
        )
        if align == "topright":
            top_left = QPoint(inner.right() - w + 1, inner.top())
        elif align == "topcenter":
            top_left = QPoint(inner.center().x() - w // 2, inner.top())
        elif align == "center":
            center = inner.center()
            top_left = QPoint(center.x() - w // 2, center.y() - h // 2)
        else:
            top_left = inner.topLeft()
        new = QRect(top_left, QSize(w, h))
        # 平移进绘制范围；范围本身放不下时才裁边
        if bounds is None:
            bounds = self.rect()
        if bounds.width() > 0 and bounds.height() > 0:
            if new.right() > bounds.right():
                new.moveRight(bounds.right())
            if new.left() < bounds.left():
                new.moveLeft(bounds.left())
            if new.bottom() > bounds.bottom():
                new.moveBottom(bounds.bottom())
            if new.top() < bounds.top():
                new.moveTop(bounds.top())
            new = new.intersected(bounds)
        return new

    def _alignment_flags(self):
        # 原地显示翻译自己的对齐设置（不共用文本设置的居中显示）
        return int(Qt.TextFlag.TextWordWrap) | _OVERLAY_ALIGN_FLAGS.get(
            globalconfig.get(
                "ocr_translation_overlay_alignment", _OVERLAY_ALIGN_DEFAULT
            ),
            _OVERLAY_ALIGN_FLAGS[_OVERLAY_ALIGN_DEFAULT],
        )

    def _local_widget_bounds(self, p0, ang):
        """选框（覆盖层）四角逆变换到旋转局部坐标的 AABB——倾斜块
        扩展/绘制时的可用范围。"""
        ca, sa = math.cos(math.radians(ang)), math.sin(math.radians(ang))
        W, H = self.width(), self.height()
        us, vs = [], []
        for x, y in ((0, 0), (W, 0), (W, H), (0, H)):
            dx, dy = x - p0.x(), y - p0.y()
            us.append(dx * ca + dy * sa)
            vs.append(-dx * sa + dy * ca)
        u1, u2, v1, v2 = min(us), max(us), min(vs), max(vs)
        if u2 <= u1 or v2 <= v1:
            return self.rect()
        return QRect(round(u1), round(v1), round(u2 - u1), round(v2 - v1))

    def _block_layout(self, i, text, cap, dpr):
        """单块绘制布局：返回 (transform, inner, outer, font)。

        transform=None 为近水平块（AABB 绘制，行为同旧版）；否则
        (p0, angle)——在 p0 平移、angle 旋转的坐标系中绘制，倾斜的
        OCR 结果让译文同样倾斜。块过小放不下时向外扩展保证完整。"""
        quad = self.block_rects[i]
        pts = [QPointF(quad[j] / dpr, quad[j + 1] / dpr) for j in (0, 2, 4, 6)]
        p0, p1, p2, p3 = pts
        ang = math.degrees(math.atan2(p1.y() - p0.y(), p1.x() - p0.x()))
        w = (
            math.hypot(p1.x() - p0.x(), p1.y() - p0.y())
            + math.hypot(p2.x() - p3.x(), p2.y() - p3.y())
        ) / 2
        h = (
            math.hypot(p3.x() - p0.x(), p3.y() - p0.y())
            + math.hypot(p2.x() - p1.x(), p2.y() - p1.y())
        ) / 2
        if abs(ang) < 0.3 or w <= 1 or h <= 1:
            # 近水平：AABB 绘制（避免变换取整带来的漂移）
            xs = [p.x() for p in pts]
            ys = [p.y() for p in pts]
            rect = QRectF(
                min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)
            )
            transform = None
            bounds = self.rect()
        else:
            rect = QRectF(0, 0, w, h)
            transform = (p0, ang)
            bounds = self._local_widget_bounds(p0, ang)
        margin = min(4, max(1, int(min(rect.width(), rect.height()) // 12)))
        inner = rect.adjusted(margin, margin, -margin, -margin).toAlignedRect()
        if inner.isEmpty():
            # 极小块：不留边距，整块作绘制区
            margin = 0
            inner = rect.toAlignedRect()
        if inner.isEmpty():
            return None
        font = self.fitted_font(inner, text, cap)
        if not self._text_fits(font, inner, text):
            # 块过小放不下：字号保持（≥下限），向外扩展绘制区
            inner = self._expanded_text_rect(inner, font, text, bounds)
        outer = inner.adjusted(-margin, -margin, margin, margin)
        return transform, inner, outer, font

    def paintEvent(self, event):
        painter = QPainter(self)
        flags = self._alignment_flags()
        # 块级：各 OCR 结果区域按位置单独绘制；背景色只画在文字块上，
        # 不铺满整个选框；字号 = 译文字号与按区域尺寸适配字号中的较小者
        blocks = self._blocktexts()
        if blocks:
            dpr = self.devicePixelRatioF() or 1.0
            cap = max(6, min(100, QFontInfo(self._translation_font()).pixelSize()))
            bg = self.background_color()
            pen = self.text_color()
            layouts = []
            for i, text in blocks:
                layout = self._block_layout(i, text, cap, dpr)
                if layout is not None:
                    layouts.append((layout, text))
            # 先画所有背景、再画所有文字：相邻块的背景不会遮挡另一块的文字
            for (transform, inner, outer, font), text in layouts:
                painter.save()
                if transform is not None:
                    painter.translate(transform[0])
                    painter.rotate(transform[1])
                painter.setClipRect(outer)
                painter.fillRect(outer, bg)
                painter.restore()
            for (transform, inner, outer, font), text in layouts:
                painter.save()
                if transform is not None:
                    painter.translate(transform[0])
                    painter.rotate(transform[1])
                painter.setClipRect(outer)
                painter.setFont(font)
                painter.setPen(pen)
                painter.drawText(inner, flags, text)
                painter.restore()
            painter.end()
            return
        # 无坐标（图片翻译、不输出坐标的 OCR）：整框绘制（原行为）
        painter.fillRect(self.rect(), self.background_color())
        margin = min(8, max(1, min(self.width(), self.height()) // 12))
        text_rect = self.rect().adjusted(margin, margin, -margin, -margin)
        painter.setClipRect(text_rect)
        painter.setFont(self.fitted_font(text_rect))
        painter.setPen(self.text_color())
        painter.drawText(text_rect, flags, self.text)
        painter.end()
